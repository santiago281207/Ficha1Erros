﻿namespace Fiha1Erros
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtName = new System.Windows.Forms.TextBox();
            this.ptbPicture = new System.Windows.Forms.PictureBox();
            this.mtbDate = new System.Windows.Forms.MaskedTextBox();
            this.mtbEmail = new System.Windows.Forms.MaskedTextBox();
            this.btnOk = new System.Windows.Forms.Button();
            this.cbClasses = new System.Windows.Forms.ComboBox();
            this.epError = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnPhoto = new System.Windows.Forms.Button();
            this.tmrEp = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.ptbPicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.epError)).BeginInit();
            this.SuspendLayout();
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(206, 26);
            this.txtName.MaxLength = 250;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(150, 22);
            this.txtName.TabIndex = 0;
            this.txtName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtName_KeyPress);
            // 
            // ptbPicture
            // 
            this.ptbPicture.Location = new System.Drawing.Point(12, 26);
            this.ptbPicture.Name = "ptbPicture";
            this.ptbPicture.Size = new System.Drawing.Size(176, 125);
            this.ptbPicture.TabIndex = 1;
            this.ptbPicture.TabStop = false;
            // 
            // mtbDate
            // 
            this.mtbDate.Location = new System.Drawing.Point(206, 65);
            this.mtbDate.Mask = "00/00/0000";
            this.mtbDate.Name = "mtbDate";
            this.mtbDate.Size = new System.Drawing.Size(150, 22);
            this.mtbDate.TabIndex = 2;
            this.mtbDate.ValidatingType = typeof(System.DateTime);
            // 
            // mtbEmail
            // 
            this.mtbEmail.Location = new System.Drawing.Point(206, 129);
            this.mtbEmail.Mask = "L000000@inete.net";
            this.mtbEmail.Name = "mtbEmail";
            this.mtbEmail.Size = new System.Drawing.Size(150, 22);
            this.mtbEmail.TabIndex = 3;
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(206, 162);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(150, 23);
            this.btnOk.TabIndex = 4;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // cbClasses
            // 
            this.cbClasses.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbClasses.FormattingEnabled = true;
            this.cbClasses.Items.AddRange(new object[] {
            ""});
            this.cbClasses.Location = new System.Drawing.Point(206, 93);
            this.cbClasses.Name = "cbClasses";
            this.cbClasses.Size = new System.Drawing.Size(150, 24);
            this.cbClasses.TabIndex = 5;
            // 
            // epError
            // 
            this.epError.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.AlwaysBlink;
            this.epError.ContainerControl = this;
            // 
            // btnPhoto
            // 
            this.btnPhoto.Location = new System.Drawing.Point(12, 162);
            this.btnPhoto.Name = "btnPhoto";
            this.btnPhoto.Size = new System.Drawing.Size(176, 23);
            this.btnPhoto.TabIndex = 6;
            this.btnPhoto.Text = "Carregar Foto";
            this.btnPhoto.UseVisualStyleBackColor = true;
            this.btnPhoto.Click += new System.EventHandler(this.btnPhoto_Click);
            // 
            // tmrEp
            // 
            this.tmrEp.Interval = 1000;
            this.tmrEp.Tick += new System.EventHandler(this.tmrEp_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(402, 200);
            this.Controls.Add(this.btnPhoto);
            this.Controls.Add(this.cbClasses);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.mtbEmail);
            this.Controls.Add(this.mtbDate);
            this.Controls.Add(this.ptbPicture);
            this.Controls.Add(this.txtName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Exercicio 1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ptbPicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.epError)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.PictureBox ptbPicture;
        private System.Windows.Forms.MaskedTextBox mtbDate;
        private System.Windows.Forms.MaskedTextBox mtbEmail;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.ComboBox cbClasses;
        private System.Windows.Forms.ErrorProvider epError;
        private System.Windows.Forms.Button btnPhoto;
        private System.Windows.Forms.Timer tmrEp;
    }
}

