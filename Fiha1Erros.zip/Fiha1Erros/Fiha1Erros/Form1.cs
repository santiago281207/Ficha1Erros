﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fiha1Erros
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            DateTime birthDate = DateTime.Now;

            if (birthDate > DateTime.Now.AddYears(-14) || birthDate < DateTime.Now.AddYears(-21))
            {
                epError.SetError(mtbDate, "Precisa de ter entre 14 e 21 anos");
                tmrEp.Start();
                
            }else if (ptbPicture.Image != null && mtbDate.Text != null && txtName.Text != null && mtbEmail.Text != null && cbClasses.SelectedItem != null)
            {
                DateTime.TryParse(Text, out birthDate);

                string name = txtName.Text;
                string email = mtbDate.Text;

                MessageBox.Show($"Aluno: {txtName.Text}\n" +
                                $"Idade: {(DateTime.Now.Year - birthDate.Year).ToString()}\n" +
                                $"Turma {cbClasses.SelectedText}\n" +
                                $"Endereço de email: {mtbEmail.Text}",
                                "Informacoes de aluno", MessageBoxButtons.OK, MessageBoxIcon.Information);

                mtbEmail.Text = "";
                mtbDate.Text = "";
                txtName.Text = "";
                cbClasses.SelectedItem = null;
                ptbPicture.Image = null;
            }else
            {
                epError.SetError(btnOk, "Preencha todos os campos");
                tmrEp.Start();
            }


        }

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled =  !Char.IsLetter(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != 32;
        }

        private void btnPhoto_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Title = "Selecionar Imagem";
                openFileDialog.Filter = "Ficheiros de Imagem|*.jpg;*.jpeg;*.png;*.bmp;*.gif";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    ptbPicture.Image = Image.FromFile(openFileDialog.FileName);
                }
            }
        }

        private void tmrEp_Tick(object sender, EventArgs e)
        {
            epError.SetError(btnOk,"");
            tmrEp.Stop();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for(int i = 24; i < 66;i++)
            {
                cbClasses.Items.Add($"TGPSI {i}/01");
                cbClasses.Items.Add($"TGPSI {i}/02");
            }
        }
    }
}
